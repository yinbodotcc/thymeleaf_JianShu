package yinbodotcc.com.thymeleaftest.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller//不能换用@RestController
public class HelloController
{

	@RequestMapping("/hello")
	public String hello(Model m)
	{
		m.addAttribute("name", "thymeleaf");
		return "hello";
	}
	// Rest一般是这种写法
	// @GetMapping("/hello2")
	// public String hello()
	// {
	// 		return "Hello World, from Spring Boot 2!";
	// }
}