function testFunction()
{
    alert("test Thymeleaf.js!");
}